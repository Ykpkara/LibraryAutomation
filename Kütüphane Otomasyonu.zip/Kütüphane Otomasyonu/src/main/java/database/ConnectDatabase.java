package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDatabase {
    private static final String URL = "jdbc:mysql://localhost:3306/library_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "Boz5parmak.";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            if (conn != null) {
                return conn;
            }
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL Driver Bulunamadı: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Veritabanı Bağlantı Hatası! Lütfen MySQL servisinin açık olduğunu kontrol edin: " + e.getMessage());
        }
        return null;
    }
}