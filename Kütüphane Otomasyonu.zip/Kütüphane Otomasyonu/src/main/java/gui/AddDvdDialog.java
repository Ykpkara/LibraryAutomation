package gui;

import service.ItemManager;
import javax.swing.*;
import java.awt.*;

public class AddDvdDialog extends JDialog {
    private JTextField txtName = new JTextField(15);
    private JTextField txtBrand = new JTextField(15);

    private JButton btnSave = new JButton("KAYDET");
    private JButton btnCancel = new JButton("Geri Dön");

    public AddDvdDialog(JFrame parent, ItemManager itemManager, Runnable onUpdate) {
        super(parent, "Yeni DVD Ekle", true);

        JPanel contentPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        contentPanel.add(new JLabel("DVD Adı:"));       contentPanel.add(txtName);
        contentPanel.add(new JLabel("Marka/Stüdyo:"));  contentPanel.add(txtBrand);


        JPanel btnGroup = new JPanel(new GridLayout(1, 2, 10, 0));
        btnGroup.add(btnCancel);
        btnGroup.add(btnSave);

        contentPanel.add(new JLabel(""));
        contentPanel.add(btnGroup);


        applyGreenStyle(btnSave);
        applyGrayStyle(btnCancel);

        add(contentPanel);


        btnCancel.addActionListener(e -> dispose());

        btnSave.addActionListener(e -> {
            try {
                String name = txtName.getText().trim();
                String brand = txtBrand.getText().trim();

                if (name.isEmpty() || brand.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun!", "Uyarı", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                itemManager.addDvd(name, brand);

                JOptionPane.showMessageDialog(this, "DVD Başarıyla Eklendi!");
                if (onUpdate != null) onUpdate.run();
                dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Hata: " + ex.getMessage());
            }
        });

        pack();
        setLocationRelativeTo(parent);
    }

    private void applyGreenStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(34, 139, 34));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void applyGrayStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(Color.GRAY);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}