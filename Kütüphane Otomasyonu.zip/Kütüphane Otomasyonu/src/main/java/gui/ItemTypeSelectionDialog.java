package gui;

import javax.swing.*;
import java.awt.*;
import service.ItemManager;

public class ItemTypeSelectionDialog extends JDialog {

    public ItemTypeSelectionDialog(JFrame parent, ItemManager itemManager, Runnable onUpdate) {
        super(parent, "Öğe Türü Seçin", true);
        setSize(400, 200);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel container = new JPanel(new GridLayout(1, 3, 10, 10));
        container.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        JButton btnBook = new JButton("📚 KİTAP");
        JButton btnDvd = new JButton("💿 DVD");
        JButton btnMagazine = new JButton("📰 DERGİ");


        applyBlueStyle(btnBook);
        applyBlueStyle(btnDvd);
        applyBlueStyle(btnMagazine);


        btnBook.addActionListener(e -> {
            dispose();
            new AddBookDialog(parent, itemManager, onUpdate).setVisible(true);
        });

        btnDvd.addActionListener(e -> {
            dispose();
            new AddDvdDialog(parent, itemManager, onUpdate).setVisible(true);
        });

        btnMagazine.addActionListener(e -> {
            dispose();
            new AddMagazineDialog(parent, itemManager, onUpdate).setVisible(true);
        });

        container.add(btnBook);
        container.add(btnDvd);
        container.add(btnMagazine);

        add(new JLabel("Eklemek istediğiniz materyal türünü seçiniz:", SwingConstants.CENTER), BorderLayout.NORTH);
        add(container, BorderLayout.CENTER);
    }

    private void applyBlueStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(70, 130, 180));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(50, 100, 150));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(70, 130, 180));
            }
        });
    }
}