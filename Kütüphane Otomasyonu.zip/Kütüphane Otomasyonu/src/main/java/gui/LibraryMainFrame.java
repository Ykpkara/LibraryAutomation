package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.*;
import service.*;
import utils.FrameConfig;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LibraryMainFrame extends JFrame {
    private ItemManager itemManager = new ItemManager();
    private MemberManager memberManager = new MemberManager();
    private OfficerManager officerManager = new OfficerManager();

    private JTabbedPane tabbedPane;
    private DefaultTableModel itemModel, requestModel, personModel;
    private DefaultTableModel activeModel, pendingModel, historyModel;

    private JTable itemTable, requestTable, personTable;
    private JComboBox<String> typeFilter, personTypeFilter, requestFilter;

    private DefaultTableModel memberModel;
    private JTable memberTable;

    private JComboBox<String> accountRequestFilter;

    private boolean isAdmin;
    private int currentUserId;

    public LibraryMainFrame(boolean isAdmin, int userId) {

        FrameConfig.setAppIcon(this);

        this.isAdmin = isAdmin;
        this.currentUserId = userId;

        setTitle("Kütüphane Yönetim Sistemi | " + (isAdmin ? "Yönetici" : "Üye No: " + userId));
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());


        add(createTopNavigationPanel(), BorderLayout.NORTH);


        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("📦 Envanter Listesi", createInventoryPanel());

        if (this.isAdmin) {
            tabbedPane.addTab("📩 Talepler ve Onaylar", createRequestPanel());
            tabbedPane.addTab("👥 Üye ve Personel", createPersonPanel());
            tabbedPane.addTab("👤 Hesap ve Yönetim", createAccountPanel());
        } else {
            tabbedPane.addTab("👤 Hesabım", createAccountPanel());
        }


        tabbedPane.addChangeListener(e -> {
            int index = tabbedPane.getSelectedIndex();
            String title = tabbedPane.getTitleAt(index);

            if (title.contains("Talepler")) {
                loadRequests();
            } else if (title.contains("Envanter")) {
                loadItems();
            } else if (title.contains("Üye") || title.contains("Personel")) {
                loadPeople();
            } else if (title.contains("Hesap")) {
                refreshAccountTables();
            }
        });

        add(tabbedPane, BorderLayout.CENTER);
        setVisible(true);
    }

    private JPanel createTopNavigationPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(240, 240, 240));
        topPanel.setPreferredSize(new Dimension(1200, 50));
        topPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));

        String status = isAdmin ? "🔐 MOD: GÖREVLİ" : "👁️ MOD: ÜYE";
        JLabel lblStatus = new JLabel("  " + status + " | Kullanıcı ID: " + currentUserId);
        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JButton btnLogout = new JButton("Oturumu Kapat");
        applyButtonStyle(btnLogout);
        btnLogout.addActionListener(e -> { this.dispose(); new RoleSelectionFrame(); });

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
        rightPanel.setOpaque(false);
        rightPanel.add(btnLogout);

        topPanel.add(lblStatus, BorderLayout.WEST);
        topPanel.add(rightPanel, BorderLayout.EAST);
        return topPanel;
    }

    private JPanel createInventoryPanel() {
        System.out.println("Envanter Paneli Oluşturuluyor. Admin mi? " + isAdmin);

        JPanel panel = new JPanel(new BorderLayout());

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        filterPanel.add(new JLabel("Kategori:"));
        typeFilter = new JComboBox<>(new String[]{"Hepsi", "Kitap", "DVD", "Dergi"});
        typeFilter.addActionListener(e -> loadItems());
        filterPanel.add(typeFilter);

        // --- 2. ORTA PANEL: TABLO ---
        itemModel = new DefaultTableModel(new String[]{"ID", "İsim", "Tür", "Yazar/Marka", "Durum"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        itemTable = new JTable(itemModel);
        itemTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);


        loadItems();


        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton btnAdd = new JButton("Yeni Öğe Ekle");
        JButton btnDelete = new JButton("Öğeyi Sil");
        JButton btnBorrow = new JButton("Seçilenleri Ödünç Al");


        applyGreenButtonStyle(btnAdd);
        applyRedButtonStyle(btnDelete);
        applyButtonStyle(btnBorrow);


        btnAdd.setVisible(isAdmin);
        btnDelete.setVisible(isAdmin);
        btnBorrow.setVisible(!isAdmin);

        btnPanel.add(btnAdd);
        btnPanel.add(btnDelete);
        btnPanel.add(btnBorrow);


        btnAdd.addActionListener(e -> {
            new ItemTypeSelectionDialog(this, itemManager, this::loadItems).setVisible(true);
        });


        btnDelete.addActionListener(e -> {
            int[] selectedRows = itemTable.getSelectedRows();

            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Lütfen silmek istediğiniz ürünleri seçin.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    selectedRows.length + " adet ürün kalıcı olarak silinecek. Emin misiniz?",
                    "Çoklu Silme Onayı", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                List<Integer> idsToDelete = new ArrayList<>();
                for (int row : selectedRows) {
                    idsToDelete.add((Integer) itemModel.getValueAt(row, 0));
                }

                for (int itemId : idsToDelete) {
                    itemManager.deleteItem(itemId);
                }

                loadItems();
                JOptionPane.showMessageDialog(this, "Seçilen ürünler başarıyla silindi.");
            }
        });


        btnBorrow.addActionListener(e -> {
            int[] selectedRows = itemTable.getSelectedRows();
            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Lütfen ödünç almak istediğiniz ürünleri seçin.");
                return;
            }

            int count = 0;
            for (int row : selectedRows) {
                String status = (String) itemModel.getValueAt(row, 4);

                if (status.contains("Mevcut")) {
                    int itemId = (int) itemModel.getValueAt(row, 0);
                    officerManager.createRequest(currentUserId, itemId, "BORROW");
                    count++;
                }
            }

            if (count > 0) {
                JOptionPane.showMessageDialog(this, count + " adet ürün için talebiniz iletildi.");


                loadItems();


                refreshAccountTables();

            } else {
                JOptionPane.showMessageDialog(this, "Seçilen ürünler şu an ödünç alınabilir durumda değil (Zaten ödünçte veya talep edilmiş).", "Uyarı", JOptionPane.WARNING_MESSAGE);
            }
        });


        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(itemTable), BorderLayout.CENTER);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createAccountPanel() {

        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 20, 20));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        LibraryPerson p = memberManager.getPersonById(currentUserId);


        JPanel leftColumn = new JPanel(new GridLayout(2, 1, 0, 20));


        JPanel profileContainer = new JPanel(new BorderLayout(10, 10));
        profileContainer.setBorder(BorderFactory.createTitledBorder("👤 Profil Yönetimi"));
        JComboBox<String> profileMenu = new JComboBox<>(new String[]{"Bilgilerim", "Şifre Değiştir"});
        CardLayout cl = new CardLayout();
        JPanel cardPanel = new JPanel(cl);
        cardPanel.add(createInfoPage(p), "Bilgilerim");
        cardPanel.add(createPasswordPage(), "Şifre Değiştir");
        profileContainer.add(profileMenu, BorderLayout.NORTH);
        profileContainer.add(cardPanel, BorderLayout.CENTER);
        profileMenu.addActionListener(e -> cl.show(cardPanel, (String) profileMenu.getSelectedItem()));


        JPanel historyPanel = new JPanel(new BorderLayout());
        historyPanel.setBorder(BorderFactory.createTitledBorder("✅ Ürün Geçmişim"));
        historyModel = new DefaultTableModel(new String[]{"Ürün Adı", "Tür"}, 0);
        historyPanel.add(new JScrollPane(new JTable(historyModel)), BorderLayout.CENTER);

        if (isAdmin) historyPanel.setVisible(false);
        leftColumn.add(profileContainer);
        leftColumn.add(historyPanel);


        JPanel rightColumn = new JPanel(new GridLayout(2, 1, 0, 20));


        JPanel activePanel = new JPanel(new BorderLayout(5, 5));
        activePanel.setBorder(BorderFactory.createTitledBorder("📖 Şu An Kullandıklarım"));
        activeModel = new DefaultTableModel(new String[]{"ID", "Ürün Adı", "Tür"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable activeTable = new JTable(activeModel);
        activeTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JButton btnReturn = new JButton("SEÇİLENLERİ İADE ET");
        applyGreenButtonStyle(btnReturn);
        btnReturn.addActionListener(e -> {
            int[] selectedRows = activeTable.getSelectedRows();
            if (selectedRows.length > 0) {
                int confirm = JOptionPane.showConfirmDialog(this, "İade talebi oluşturulsun mu?", "Onay", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    for (int row : selectedRows) {
                        int itemId = (int) activeModel.getValueAt(row, 0);
                        officerManager.createReturnRequest(currentUserId, itemId);
                    }
                    refreshAccountTables();
                    JOptionPane.showMessageDialog(this, "İade talepleriniz iletildi.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Lütfen ürün seçin.");
            }
        });
        activePanel.add(new JScrollPane(activeTable), BorderLayout.CENTER);
        activePanel.add(btnReturn, BorderLayout.SOUTH);


        JPanel pendingPanel = new JPanel(new BorderLayout());
        pendingPanel.setBorder(BorderFactory.createTitledBorder("⏳ Taleplerim"));
        accountRequestFilter = new JComboBox<>(new String[]{"Hepsi", "Ödünç Alma", "İade"});
        accountRequestFilter.addActionListener(e -> refreshAccountTables());
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Filtrele:")); filterPanel.add(accountRequestFilter);
        pendingPanel.add(filterPanel, BorderLayout.NORTH);

        pendingModel = new DefaultTableModel(new String[]{"Ürün Adı", "Tür", "Durum"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable pendingTable = new JTable(pendingModel);
        pendingTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JButton btnCancelRequest = new JButton("SEÇİLİ TALEPLERİ İPTAL ET");
        applyRedButtonStyle(btnCancelRequest);
        btnCancelRequest.addActionListener(e -> {
            int[] selectedRows = pendingTable.getSelectedRows();
            if (selectedRows.length > 0) {
                if (JOptionPane.showConfirmDialog(this, "İptal edilsin mi?", "Onay", 0) == 0) {
                    List<String> items = new ArrayList<>();
                    for (int r : selectedRows) items.add((String) pendingModel.getValueAt(r, 0));
                    for (String name : items) memberManager.cancelUserRequest(currentUserId, name);
                    refreshAccountTables(); loadItems();
                }
            }
        });
        pendingPanel.add(new JScrollPane(pendingTable), BorderLayout.CENTER);
        pendingPanel.add(btnCancelRequest, BorderLayout.SOUTH);

        rightColumn.add(activePanel);
        rightColumn.add(pendingPanel);


        if (isAdmin) {
            JPanel adminStatsPanel = new JPanel(new BorderLayout(10, 10));
            adminStatsPanel.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createEtchedBorder(), "📊 Detaylı Sistem Denetimi",
                    0, 0, new Font("Segoe UI", Font.BOLD, 16)));

            JPanel filterContainer = new JPanel(new GridLayout(2, 1, 5, 5));
            JComboBox<String> statsCombo = new JComboBox<>(new String[]{"Ürün Detayları", "Genel Kişi Listesi"});
            JComboBox<String> subTypeCombo = new JComboBox<>(new String[]{"BOOK", "DVD", "MAGAZINE"});

            filterContainer.add(statsCombo);
            filterContainer.add(subTypeCombo);

            DefaultTableModel statsModel = new DefaultTableModel() {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
            JTable statsTable = new JTable(statsModel);
            statsTable.setRowHeight(25);

            Runnable updateTableLogic = () -> {
                statsModel.setRowCount(0);
                String selected = (String) statsCombo.getSelectedItem();

                if ("Ürün Detayları".equals(selected)) {
                    subTypeCombo.setVisible(true);
                    statsModel.setColumnIdentifiers(new String[]{"ID", "Ad", "Tür", "Durum", "Kullanıcı ID", "Kullanıcı Ad"});

                    String selectedType = (String) subTypeCombo.getSelectedItem();
                    List<Object[]> data = officerManager.getDetailedProductStats(selectedType);

                    int onLoanCount = 0;
                    int pendingCount = 0;

                    for (Object[] row : data) {
                        statsModel.addRow(row);
                        // Durum sayacı
                        String status = row[3].toString();
                        if (status.equals("Ödünçte")) onLoanCount++;
                        if (status.contains("Bekliyor")) pendingCount++;
                    }


                    if (statsModel.getRowCount() > 0) {
                        statsModel.addRow(new Object[]{
                                "ÖZET:",
                                "Toplam: " + data.size(),
                                "-",
                                "-",
                                "-",
                                "-"
                        });
                    }
                } else {
                    subTypeCombo.setVisible(false);
                    statsModel.setColumnIdentifiers(new String[]{"Kategori", "Sayı", "-", "-", "-", "-"});
                    statsModel.addRow(new Object[]{"Kayıtlı Üyeler", memberManager.getTotalMemberCount(), "", "", "", ""});
                    statsModel.addRow(new Object[]{"Aktif Görevliler", 1, "", "", "", ""});
                }
                adminStatsPanel.revalidate();
            };

            statsCombo.addActionListener(e -> updateTableLogic.run());
            subTypeCombo.addActionListener(e -> updateTableLogic.run());

            updateTableLogic.run();

            adminStatsPanel.add(filterContainer, BorderLayout.NORTH);
            adminStatsPanel.add(new JScrollPane(statsTable), BorderLayout.CENTER);

            mainPanel.add(leftColumn);
            mainPanel.add(adminStatsPanel);
        } else {
            mainPanel.add(leftColumn);
            mainPanel.add(rightColumn);
        }

        refreshAccountTables();
        return mainPanel;
    }

    private void applyButtonStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(70, 130, 180)); // Mavi Tonu
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private JPanel createInfoPage(LibraryPerson p) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); gbc.fill = GridBagConstraints.HORIZONTAL;
        JTextField txtN = new JTextField(p.getName(), 12);
        JTextField txtL = new JTextField(p.getLastName(), 12);
        JTextField txtE = new JTextField(p.getEmail(), 12);
        JTextField txtP = new JTextField(p.getPhone(), 12);
        JButton btn = new JButton("Bilgileri Güncelle");
        applyButtonStyle(btn);
        gbc.gridx = 0; gbc.gridy = 0; panel.add(new JLabel("İsim:"), gbc);
        gbc.gridx = 1; panel.add(txtN, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(new JLabel("Soyisim:"), gbc);
        gbc.gridx = 1; panel.add(txtL, gbc);
        gbc.gridx = 0; gbc.gridy = 2; panel.add(new JLabel("E-Mail:"), gbc);
        gbc.gridx = 1; panel.add(txtE, gbc);
        gbc.gridx = 0; gbc.gridy = 3; panel.add(new JLabel("Tel:"), gbc);
        gbc.gridx = 1; panel.add(txtP, gbc);
        gbc.gridx = 1; gbc.gridy = 4; panel.add(btn, gbc);
        btn.addActionListener(e -> {
            memberManager.updatePersonInfo(currentUserId, txtN.getText(), txtL.getText(), txtE.getText(), txtP.getText());
            JOptionPane.showMessageDialog(this, "Profil bilgileriniz güncellendi.");
        });
        return panel;
    }

    private JPanel createPasswordPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); gbc.fill = GridBagConstraints.HORIZONTAL;
        JPasswordField p1 = new JPasswordField(12); JPasswordField p2 = new JPasswordField(12);
        JButton btn = new JButton("Şifreyi Değiştir");
        applyButtonStyle(btn);
        gbc.gridx = 0; gbc.gridy = 0; panel.add(new JLabel("Eski Şifre:"), gbc);
        gbc.gridx = 1; panel.add(p1, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(new JLabel("Yeni Şifre:"), gbc);
        gbc.gridx = 1; panel.add(p2, gbc);
        gbc.gridx = 1; gbc.gridy = 2; panel.add(btn, gbc);
        btn.addActionListener(e -> {
            if (memberManager.updatePassword(currentUserId, new String(p1.getPassword()), new String(p2.getPassword())))
                JOptionPane.showMessageDialog(this, "Şifreniz değiştirildi.");
            else JOptionPane.showMessageDialog(this, "Hata: Mevcut şifre yanlış!");
        });
        return panel;
    }

    private void refreshAccountTables() {

        if (activeModel == null || pendingModel == null) return;

        try {
            activeModel.setRowCount(0);

            if (!isAdmin) {
                List<String[]> activeData = memberManager.getUserBooksByStatus(currentUserId, "APPROVED");

                for (String[] row : activeData) {

                    activeModel.addRow(new Object[]{
                            Integer.parseInt(row[0]),
                            row[1],
                            row[2]
                    });
                }


                String selectedFilter = "Hepsi";
                if (accountRequestFilter != null && accountRequestFilter.getSelectedItem() != null) {
                    selectedFilter = accountRequestFilter.getSelectedItem().toString();
                }


                updatePendingRequestsTable(selectedFilter);
                updateHistoryTable("Hepsi");
            }


            revalidate();
            repaint();

        } catch (Exception e) {
            System.err.println("Hesap tabloları yenilenirken hata oluştu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private JPanel createRequestPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        requestFilter = new JComboBox<>(new String[]{"Tüm Talepler", "Ödünç Alma Talepleri", "İade Talepleri"});
        requestFilter.addActionListener(e -> loadRequests());

        filterPanel.add(new JLabel("Talep Türü Filtresi: "));
        filterPanel.add(requestFilter);


        requestModel = new DefaultTableModel(new String[]{"Talep No", "Üye No", "Eser No", "İşlem Türü", "Mevcut Durum"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        requestTable = new JTable(requestModel);
        requestTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);


        loadRequests();


        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        JButton btnApprove = new JButton("Seçilen Talepleri Onayla");
        JButton btnReject = new JButton("Seçilen Talepleri Reddet");


        applyGreenButtonStyle(btnApprove);


        btnReject.setBackground(new Color(200, 35, 35));
        btnReject.setForeground(Color.WHITE);
        btnReject.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnReject.setFocusPainted(false);
        btnReject.setBorderPainted(false);
        btnReject.setOpaque(true);
        btnReject.setCursor(new Cursor(Cursor.HAND_CURSOR));


        btnApprove.addActionListener(e -> {
            int[] selectedRows = requestTable.getSelectedRows();
            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Lütfen onaylamak istediğiniz talepleri tablodan seçiniz.", "Uyarı", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int count = 0;
            for (int row : selectedRows) {
                int requestId = (int) requestModel.getValueAt(row, 0);

                String uiStatus = requestModel.getValueAt(row, 4).toString();


                String targetDbStatus = uiStatus.contains("İade") ? "RETURNED" : "APPROVED";

                officerManager.handleRequest(requestId, targetDbStatus);
                count++;
            }

            JOptionPane.showMessageDialog(this, count + " adet talep başarıyla onaylandı.", "İşlem Başarılı", JOptionPane.INFORMATION_MESSAGE);


            loadRequests();
            loadItems();
        });


        btnReject.addActionListener(e -> {
            int[] selectedRows = requestTable.getSelectedRows();
            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Lütfen reddetmek istediğiniz talepleri seçiniz.", "Uyarı", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    selectedRows.length + " adet talebi reddetmek istediğinize emin misiniz?",
                    "Toplu İşlem Onayı",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                for (int row : selectedRows) {
                    int requestId = (int) requestModel.getValueAt(row, 0);
                    officerManager.handleRequest(requestId, "REJECTED");
                }


                loadRequests();
                loadItems();
                JOptionPane.showMessageDialog(this, "Seçilen talepler reddedildi.");
            }
        });

        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(requestTable), BorderLayout.CENTER);

        btnPanel.add(btnApprove);
        btnPanel.add(btnReject);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void applyGreenButtonStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(34, 139, 34));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));


        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(28, 110, 28));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(34, 139, 34));
            }
        });
    }


    private void applyRedButtonStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(220, 20, 60));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(178, 34, 34)); // Firebrick Kırmızı
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(220, 20, 60));
            }
        });
    }

    private JPanel createPersonPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        personTypeFilter = new JComboBox<>(new String[]{"Hepsi", "Üyeler", "Görevliler"});


        personTypeFilter.addActionListener(e -> loadPeople());

        filterPanel.add(new JLabel("Görüntüleme: "));
        filterPanel.add(personTypeFilter);


        personModel = new DefaultTableModel(new String[]{"ID", "İsim", "Soyisim", "Yetki Rolü"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        personTable = new JTable(personModel);


        personTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);


        loadPeople();


        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        JButton btnAdd = new JButton("➕ Kayıt Ekle");
        JButton btnDel = new JButton("🗑️ Kaydı Sil");

        applyGreenButtonStyle(btnAdd);
        applyRedButtonStyle(btnDel);


        btnAdd.addActionListener(e -> {

            Object[] options = {"Üye Ekle", "Görevli Ekle"};


            int choice = JOptionPane.showOptionDialog(this,
                    "Sisteme hangi türde kullanıcı eklemek istiyorsunuz?",
                    "Yeni Kayıt Türü",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]);


            if (choice == 0) {

                new AddMemberDialog(this, memberManager).setVisible(true);
                loadPeople();
            } else if (choice == 1) {

                new AddOfficerDialog(this, officerManager).setVisible(true);
                loadPeople();
            }
        });


        btnDel.addActionListener(e -> {
            int[] selectedRows = personTable.getSelectedRows();

            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Lütfen silmek istediğiniz kişi(leri) seçin.");
                return;
            }


            boolean containsSelf = false;
            for (int row : selectedRows) {
                int id = (int) personModel.getValueAt(row, 0);
                if (id == currentUserId) {
                    containsSelf = true;
                    break;
                }
            }

            if (containsSelf) {
                JOptionPane.showMessageDialog(this, "Seçilenler arasında kendi hesabınız bulunuyor. Kendi hesabınızı silemezsiniz!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    selectedRows.length + " kişi sistemden tamamen silinecek. Onaylıyor musunuz?",
                    "Kritik Çoklu Silme Onayı", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {

                List<Integer> idsToDelete = new ArrayList<>();
                for (int row : selectedRows) {
                    idsToDelete.add((Integer) personModel.getValueAt(row, 0));
                }


                for (int id : idsToDelete) {
                    memberManager.deletePerson(id);
                }


                loadPeople();


                if (isAdmin) refreshAccountTables();

                JOptionPane.showMessageDialog(this, "Seçilen " + idsToDelete.size() + " kayıt başarıyla silindi.");
            }
        });

        btnPanel.add(btnAdd);
        btnPanel.add(btnDel);

        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(personTable), BorderLayout.CENTER);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadItems() {
        if (itemModel == null) return;
        itemModel.setRowCount(0);
        String sel = typeFilter.getSelectedItem().toString();
        for (LibraryItem i : itemManager.getAllItems()) {
            String type = i instanceof Book ? "Kitap" : (i instanceof Dvd ? "DVD" : "Dergi");
            String extra = "";
            if (i instanceof Book) extra = ((Book) i).getAuthor();
            else if (i instanceof Dvd) extra = ((Dvd) i).getBrand();
            else if (i instanceof Magazine) extra = ((Magazine) i).getBrand();

            if (sel.equals("Hepsi") || sel.equals(type)) {
                String st = !i.isAvailable() ? "🔴 Ödünçte" : (officerManager.isItemUnderRequest(i.getId()) ? "⏳ Onay Bekliyor" : "🟢 Mevcut");
                itemModel.addRow(new Object[]{i.getId(), i.getName(), type, extra, st});
            }
        }
    }

    private void loadRequests() {

        if (requestModel == null) return;


        requestModel.setRowCount(0);

        String filterValue = (requestFilter != null) ? (String) requestFilter.getSelectedItem() : "Tüm Talepler";


        StringBuilder sql = new StringBuilder("SELECT * FROM requests WHERE status LIKE '%PENDING%'");


        if ("Ödünç Alma Talepleri".equals(filterValue)) {
            sql.append(" AND request_type = 'BORROW'");
        } else if ("İade Talepleri".equals(filterValue)) {
            sql.append(" AND request_type = 'RETURN'");
        }

        sql.append(" ORDER BY request_id DESC");

        try (Connection conn = database.ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString());
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int requestId = rs.getInt("request_id");
                int memberId = rs.getInt("member_id");
                int itemId = rs.getInt("item_id");
                String type = rs.getString("request_type");
                String status = rs.getString("status");



                String trType = type.equals("BORROW") ? "Ödünç Alma" : "İade Etme";


                String trStatus;

                if (status.contains("PENDING")) {

                    if (type.equals("RETURN")) {
                        trStatus = "İade Onayı Bekliyor";
                    } else {
                        trStatus = "Ödünç Onayı Bekliyor";
                    }
                } else {

                    trStatus = status;
                }

                requestModel.addRow(new Object[]{requestId, memberId, itemId, trType, trStatus});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Talepler yüklenirken hata oluştu: " + e.getMessage());
        }
    }

    private void updatePendingRequestsTable(String filter) {

        if (pendingModel == null) return;


        pendingModel.setRowCount(0);


        if (filter.equals("Hepsi") || filter.equals("Ödünç Alma")) {
            for (String[] r : memberManager.getUserRequestsByStatus(currentUserId, "PENDING")) {
                pendingModel.addRow(r);
            }
        }


        if (filter.equals("Hepsi") || filter.equals("İade")) {
            for (String[] r : memberManager.getUserRequestsByStatus(currentUserId, "RETURN_PENDING")) {
                pendingModel.addRow(r);
            }
        }
    }

    private void updateHistoryTable(String f) {
        if (historyModel == null) return;
        historyModel.setRowCount(0);
        for (String[] row : memberManager.getUniqueUserBookHistory(currentUserId)) historyModel.addRow(row);
    }


    private void setAppIcon() {
        try {

            URL iconURL = getClass().getResource("/book_icon.png");

            if (iconURL != null) {
                ImageIcon icon = new ImageIcon(iconURL);
                this.setIconImage(icon.getImage());
                System.out.println("✅ İkon başarıyla yüklendi.");
            } else {

                System.err.println("❌ HATA: 'book_icon.png' dosyası resources klasöründe bulunamadı!");
            }
        } catch (Exception e) {
            System.err.println("❌ İkon yüklenirken teknik hata oluştu: " + e.getMessage());
        }
    }

    private void loadPeople() {

        if (personModel == null) return;


        personModel.setRowCount(0);




        String filterValue = (personTypeFilter != null) ? (String) personTypeFilter.getSelectedItem() : "Hepsi";


        StringBuilder sql = new StringBuilder("SELECT id, name, last_name, role FROM library_people");


        if ("Üyeler".equals(filterValue)) {

            sql.append(" WHERE role = 'MEMBER'");
        } else if ("Görevliler".equals(filterValue)) {

            sql.append(" WHERE role = 'OFFICER'");
        }


        sql.append(" ORDER BY id ASC");


        try (Connection conn = database.ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString());
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String lastName = rs.getString("last_name");
                String role = rs.getString("role");


                String trRole = "Üye";
                if (role != null) {
                    if (role.equalsIgnoreCase("ADMIN")) trRole = "Yönetici";
                    else if (role.equalsIgnoreCase("OFFICER")) trRole = "Görevli";
                }


                personModel.addRow(new Object[]{id, name, lastName, trRole});
            }
            System.out.println("✅ Kişiler listesi başarıyla güncellendi. Filtre: " + filterValue);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Kişiler yüklenirken hata oluştu: " + e.getMessage(), "Veritabanı Hatası", JOptionPane.ERROR_MESSAGE);
        }
    }
}