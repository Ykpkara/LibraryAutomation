package gui;

import database.ConnectDatabase;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;
import utils.FrameConfig;

public class LoginFrame extends JFrame {
    private JTextField txtId = new JTextField(15);
    private JPasswordField txtPass = new JPasswordField(15);
    private JButton btnLogin = new JButton("Sisteme Giriş Yap");
    private JButton btnBack = new JButton("Geri Dön");

    public LoginFrame() {

        FrameConfig.setAppIcon(this);

        setTitle("Kütüphane Yönetim Sistemi | Giriş");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);


        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        mainPanel.setBackground(new Color(245, 245, 245));

        JLabel lblTitle = new JLabel("HOŞ GELDİNİZ");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(new Color(50, 50, 50));
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);


        JPanel fieldsPanel = new JPanel(new GridLayout(2, 2, 10, 20));
        fieldsPanel.setOpaque(false);
        fieldsPanel.setMaximumSize(new Dimension(320, 100));

        JLabel lblId = new JLabel("Kullanıcı ID:");
        lblId.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JLabel lblPass = new JLabel("Şifre:");
        lblPass.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        fieldsPanel.add(lblId);
        fieldsPanel.add(txtId);
        fieldsPanel.add(lblPass);
        fieldsPanel.add(txtPass);


        applyButtonStyle(btnLogin);
        applySecondaryButtonStyle(btnBack);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setOpaque(false);
        btnLogin.setPreferredSize(new Dimension(160, 40));
        btnBack.setPreferredSize(new Dimension(100, 40));


        KeyAdapter enterKeyAdapter = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    handleLogin();
                }
            }
        };
        txtId.addKeyListener(enterKeyAdapter);
        txtPass.addKeyListener(enterKeyAdapter);


        btnLogin.addActionListener(e -> handleLogin());
        btnBack.addActionListener(e -> {
            new RoleSelectionFrame();
            this.dispose();
        });

        buttonPanel.add(btnLogin);
        buttonPanel.add(btnBack);

        mainPanel.add(lblTitle);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        mainPanel.add(fieldsPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        mainPanel.add(buttonPanel);

        add(mainPanel);


        SwingUtilities.invokeLater(() -> txtId.requestFocusInWindow());

        setVisible(true);
    }

    private void handleLogin() {
        String idText = txtId.getText().trim();
        String pass = new String(txtPass.getPassword());

        if (idText.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun!", "Uyarı", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int id = Integer.parseInt(idText);
            String role = getAuthenticatedRole(id, pass);

            if (role != null) {

                boolean isAdmin = "OFFICER".equalsIgnoreCase(role);
                new LibraryMainFrame(isAdmin, id);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Hatalı Kullanıcı ID veya Şifre!", "Giriş Başarısız", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID sadece rakamlardan oluşmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getAuthenticatedRole(int id, String pass) {
        String sql = "SELECT role FROM library_people WHERE id = ? AND password = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (conn == null) return null;
            pstmt.setInt(1, id);
            pstmt.setString(2, pass);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getString("role");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Veritabanı bağlantı hatası: " + e.getMessage());
        }
        return null;
    }

    private void applyButtonStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(70, 130, 180));
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void applySecondaryButtonStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(120, 120, 120));
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}