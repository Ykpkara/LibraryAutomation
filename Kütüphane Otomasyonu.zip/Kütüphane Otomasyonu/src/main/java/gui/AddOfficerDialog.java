package gui;

import model.Officers;
import service.OfficerManager;
import javax.swing.*;
import java.awt.*;

public class AddOfficerDialog extends JDialog {
    private JTextField txtName = new JTextField(15);
    private JTextField txtLastName = new JTextField(15);
    private JTextField txtPhone = new JTextField(15);
    private JTextField txtEmail = new JTextField(15);
    private JButton btnSave = new JButton("Görevli Kaydet");
    private boolean isSucceeded = false;

    public AddOfficerDialog(JFrame parent, OfficerManager officerManager) {

        super(parent, "Yeni Görevli Kaydı", true);


        txtName = new JTextField();
        txtLastName = new JTextField();
        txtPhone = new JTextField();
        txtEmail = new JTextField();
        btnSave = new JButton("Kaydet");
        JButton btnCancel = new JButton("Vazgeç");


        JPanel contentPanel = new JPanel(new GridLayout(5, 2, 10, 15));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        contentPanel.add(new JLabel("İsim:"));
        contentPanel.add(txtName);

        contentPanel.add(new JLabel("Soyisim:"));
        contentPanel.add(txtLastName);

        contentPanel.add(new JLabel("Telefon:"));
        contentPanel.add(txtPhone);

        contentPanel.add(new JLabel("E-Mail:"));
        contentPanel.add(txtEmail);


        contentPanel.add(btnCancel);
        contentPanel.add(btnSave);

        add(contentPanel);




        btnSave.setBackground(new Color(34, 139, 34));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.setBorderPainted(false);
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));


        btnCancel.setBackground(new Color(220, 20, 60));
        btnCancel.setForeground(Color.WHITE);
        btnCancel.setFocusPainted(false);
        btnCancel.setBorderPainted(false);
        btnCancel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnCancel.setCursor(new Cursor(Cursor.HAND_CURSOR));




        btnCancel.addActionListener(e -> dispose());


        btnSave.addActionListener(e -> {
            try {
                String name = txtName.getText().trim();
                String lastName = txtLastName.getText().trim();
                String phone = txtPhone.getText().trim();
                String email = txtEmail.getText().trim();


                if (name.isEmpty() || lastName.isEmpty() || phone.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun!", "Eksik Bilgi", JOptionPane.WARNING_MESSAGE);
                    return;
                }


                Officers officer = new Officers(0, name, lastName, phone);
                officer.setEmail(email);


                officerManager.addOfficer(officer);


                isSucceeded = true;

                JOptionPane.showMessageDialog(this, "Yeni görevli başarıyla kaydedildi.", "İşlem Başarılı", JOptionPane.INFORMATION_MESSAGE);
                dispose();

            } catch (Exception ex) {
                ex.printStackTrace(); // Konsolda hata detayını görmek için
                JOptionPane.showMessageDialog(this, "Kayıt hatası: " + ex.getMessage(), "Sistem Hatası", JOptionPane.ERROR_MESSAGE);
            }
        });

        setResizable(false);
        pack();
        setLocationRelativeTo(parent);
    }

    public boolean isSucceeded() {
        return isSucceeded;
    }
}