package gui;

import javax.swing.*;
import java.awt.*;
import service.ItemManager;

public class AddBookDialog extends JDialog {
    private JTextField txtName = new JTextField(15);
    private JTextField txtAuthor = new JTextField(15);
    private JTextField txtPage = new JTextField(15);

    private JButton btnSave = new JButton("KAYDET");
    private JButton btnCancel = new JButton("Geri Dön");

    public AddBookDialog(JFrame parent, ItemManager itemManager, Runnable onUpdate) {
        super(parent, "Yeni Kitap Ekle", true);


        JPanel contentPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        contentPanel.add(new JLabel("Kitap Adı:"));
        contentPanel.add(txtName);

        contentPanel.add(new JLabel("Yazar:"));
        contentPanel.add(txtAuthor);

        contentPanel.add(new JLabel("Sayfa Sayısı:"));
        contentPanel.add(txtPage);


        JPanel btnGroup = new JPanel(new GridLayout(1, 2, 10, 0));
        btnGroup.add(btnCancel);
        btnGroup.add(btnSave);


        contentPanel.add(new JLabel(""));
        contentPanel.add(btnGroup);


        applyGreenStyle(btnSave);
        applyGrayStyle(btnCancel);

        add(contentPanel);


        btnCancel.addActionListener(e -> dispose());


        btnSave.addActionListener(e -> {
            try {
                String name = txtName.getText().trim();
                String author = txtAuthor.getText().trim();
                String pageStr = txtPage.getText().trim();

                if (name.isEmpty() || author.isEmpty() || pageStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun!", "Uyarı", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                int page = Integer.parseInt(pageStr);


                itemManager.addBook(name, author, page);

                JOptionPane.showMessageDialog(this, "Kitap Başarıyla Eklendi!");


                if (onUpdate != null) onUpdate.run();
                dispose();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Sayfa sayısı sadece rakam olmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Hata: " + ex.getMessage());
            }
        });

        pack();
        setLocationRelativeTo(parent);
    }


    private void applyGreenStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(34, 139, 34)); // Forest Green
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }


    private void applyGrayStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(Color.GRAY);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}