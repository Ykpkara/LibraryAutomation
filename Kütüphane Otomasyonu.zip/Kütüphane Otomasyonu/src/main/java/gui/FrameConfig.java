package utils;

import javax.swing.*;
import java.awt.*;

public class FrameConfig {
    public static void setAppIcon(JFrame frame) {
        try {
            java.net.URL iconURL = FrameConfig.class.getResource("/book_icon.png");
            if (iconURL != null) {
                frame.setIconImage(new ImageIcon(iconURL).getImage());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}