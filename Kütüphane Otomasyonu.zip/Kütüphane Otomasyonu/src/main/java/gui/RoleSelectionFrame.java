package gui;

import utils.FrameConfig;

import javax.swing.*;
import java.awt.*;

public class RoleSelectionFrame extends JFrame {
    public RoleSelectionFrame() {

        FrameConfig.setAppIcon(this);

        setTitle("Kütüphane Yönetim Sistemi");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);


        JPanel mainPanel = new JPanel(new GridLayout(3, 1, 20, 20));
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));

        JLabel lblInfo = new JLabel("Lütfen Giriş Türünü Seçiniz", SwingConstants.CENTER);
        lblInfo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblInfo.setForeground(new Color(50, 50, 50));


        JButton btnUser = new JButton("👤 Üye Girişi");
        applyButtonStyle(btnUser, new Color(70, 130, 180)); // Mavi tonu (Üye)

        JButton btnOfficer = new JButton("🔑 Personel Girişi");
        applyButtonStyle(btnOfficer, new Color(60, 179, 113)); // Yeşil tonu (Personel)


        btnUser.addActionListener(e -> {
            new LoginFrame();
            this.dispose();
        });

        btnOfficer.addActionListener(e -> {
            new LoginFrame();
            this.dispose();
        });

        mainPanel.add(lblInfo);
        mainPanel.add(btnUser);
        mainPanel.add(btnOfficer);

        add(mainPanel);
        setVisible(true);
    }


    private void applyButtonStyle(JButton button, Color color) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));


        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
    }
}