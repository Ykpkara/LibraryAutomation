package gui;

import javax.swing.*;
import java.awt.*;
import service.ItemManager;

public class AddItemDialog extends JDialog {
    private JTextField txtName;
    private JTextField txtExtra1;
    private JTextField txtExtra2;
    private JLabel lblExtra1, lblExtra2;

    public AddItemDialog(JFrame parent, ItemManager itemManager, String type, Runnable onUpdate) {
        super(parent, type + " Ekle", true);
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        formPanel.add(new JLabel("Eser Adı:"));
        txtName = new JTextField();
        formPanel.add(txtName);


        lblExtra1 = new JLabel();
        txtExtra1 = new JTextField();
        lblExtra2 = new JLabel("Sayfa Sayısı:");
        txtExtra2 = new JTextField();


        if (type.equals("BOOK")) {
            lblExtra1.setText("Yazar:");
            formPanel.add(lblExtra1);
            formPanel.add(txtExtra1);

            formPanel.add(lblExtra2);
            formPanel.add(txtExtra2);
        } else {

            lblExtra1.setText(type.equals("DVD") ? "Marka/Stüdyo:" : "Yayıncı:");
            formPanel.add(lblExtra1);
            formPanel.add(txtExtra1);


            formPanel.add(new JLabel(""));
            formPanel.add(new JLabel(""));
        }


        JButton btnSave = new JButton("KAYDET");
        applyBlueStyle(btnSave);

        btnSave.addActionListener(e -> {
            String name = txtName.getText().trim();
            String extra1 = txtExtra1.getText().trim();

            if (name.isEmpty() || extra1.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun.");
                return;
            }

            try {
                if (type.equals("BOOK")) {
                    String pageStr = txtExtra2.getText().trim();
                    if (pageStr.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Sayfa sayısı girilmelidir.");
                        return;
                    }
                    int pages = Integer.parseInt(pageStr);
                    itemManager.addBook(name, extra1, pages);
                } else if (type.equals("DVD")) {
                    itemManager.addDvd(name, extra1);
                } else if (type.equals("MAGAZINE")) {
                    itemManager.addMagazine(name, extra1);
                }

                JOptionPane.showMessageDialog(this, "Başarıyla eklendi: " + name);
                onUpdate.run();
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Sayfa sayısı rakam olmalıdır!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Hata: " + ex.getMessage());
            }
        });

        add(formPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        btnPanel.setBorder(BorderFactory.createEmptyBorder(0,0,10,0));
        btnPanel.add(btnSave);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void applyBlueStyle(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(70, 130, 180));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}