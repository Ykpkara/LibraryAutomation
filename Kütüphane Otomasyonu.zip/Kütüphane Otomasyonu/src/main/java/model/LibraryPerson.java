package model;

public abstract class LibraryPerson {
    private int id;
    private String name;
    private String lastName;
    private String email;
    private String phone;


    public LibraryPerson(int id, String name, String lastName, String phone) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.phone = (phone == null || phone.isEmpty()) ? "0555 555 55 55" : phone;
        this.email = name.toLowerCase() + "@kutuphane.com";
    }


    public int getId() { return id; }
    public String getName() { return name; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }

    public void setName(String name) { this.name = name; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
}