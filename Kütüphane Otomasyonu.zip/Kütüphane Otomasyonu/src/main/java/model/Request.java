package model;

public class Request {
    public static final String TYPE_BORROW = "BORROW";
    public static final String TYPE_RETURN = "RETURN";

    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_APPROVED = "APPROVED";
    public static final String STATUS_RETURN_PENDING = "RETURN_PENDING";
    public static final String STATUS_RETURNED = "RETURNED";
    public static final String STATUS_REJECTED = "REJECTED";

    private int requestId;
    private int memberId;
    private int itemId;
    private String requestType;
    private String status;

    public Request(int requestId, int memberId, int itemId, String requestType, String status) {
        this.requestId = requestId;
        this.memberId = memberId;
        this.itemId = itemId;
        this.requestType = requestType;
        this.status = status;
    }

    // --- Getter Metotları ---
    public int getRequestId() { return requestId; }
    public int getMemberId() { return memberId; }
    public int getItemId() { return itemId; }
    public String getRequestType() { return requestType; }
    public String getStatus() { return status; }

    // --- Setter Metotları ---
    public void setStatus(String status) { this.status = status; }

    public String getTranslatedType() {
        return TYPE_BORROW.equals(requestType) ? "Ödünç Alma" : "İade Etme";
    }
}