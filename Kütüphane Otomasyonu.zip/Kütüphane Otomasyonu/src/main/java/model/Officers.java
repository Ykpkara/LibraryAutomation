package model;

public class Officers extends LibraryPerson {


    public Officers(int id, String name, String lastName, String phone) {
        super(id, name, lastName, phone);
    }

}