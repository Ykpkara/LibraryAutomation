package model;

public class Magazine extends LibraryItem {
    private int pageNumber;
    private String brand;
    private boolean isAvailable;

    public Magazine(int id, String name, int pageNumber, String brand, boolean isAvailable) {
        super(id, name);
        this.pageNumber = pageNumber;
        this.brand = brand;
        this.isAvailable = isAvailable;
    }


    public int getPageNumber() { return pageNumber; }
    public String getBrand() { return brand; }


    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }

}