package model;

public class Book extends LibraryItem {
    private int pageNumber;
    private String author;
    private boolean isAvailable;

    public Book(int id, String name, int pageNumber, String author, boolean isAvailable) {
        super(id, name);
        this.pageNumber = pageNumber;
        this.author = author;
        this.isAvailable = isAvailable;
    }


    public int getPageNumber() { return pageNumber; }
    public String getAuthor() { return author; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
}
