package model;

public class Dvd extends LibraryItem {
    private String brand;
    private boolean isAvailable;

    public Dvd(int id, String name, String brand, boolean isAvailable) {
        super(id, name);
        this.brand = brand;
        this.isAvailable = isAvailable;
    }


    public String getBrand() { return brand; }


    public boolean isAvailable() { return isAvailable; }

    public void setAvailable(boolean available) { isAvailable = available; }
}
