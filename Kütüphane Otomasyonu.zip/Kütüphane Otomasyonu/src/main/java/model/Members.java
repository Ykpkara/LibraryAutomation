package model;

public class Members extends LibraryPerson {
    public Members(int id, String name, String lastName, String phone) {
        super(id, name, lastName, phone);
    }
}