package model;

import gui.RoleSelectionFrame;
import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            UIManager.put("Label.font", new Font("Segoe UI", Font.PLAIN, 14));
            UIManager.put("Button.font", new Font("Segoe UI", Font.BOLD, 13));
        } catch (Exception e) {
            e.printStackTrace();
        }


        SwingUtilities.invokeLater(() -> {
            try {

                RoleSelectionFrame loginFrame = new RoleSelectionFrame();
                loginFrame.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                        "Uygulama başlatılırken bir hata oluştu: " + e.getMessage(),
                        "Kritik Hata",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}