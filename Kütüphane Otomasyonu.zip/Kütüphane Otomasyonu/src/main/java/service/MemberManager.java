package service;

import database.ConnectDatabase;
import model.LibraryPerson;
import model.Members;
import model.Officers;
import model.Request;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberManager {


    public void addMember(Members member) {

        String insertSql = "INSERT INTO library_people (name, last_name, role, phone, email, password) VALUES (?, ?, 'MEMBER', ?, ?, 'TEMP')";
        String updateSql = "UPDATE library_people SET password = ? WHERE id = ?";

        try (Connection conn = ConnectDatabase.getConnection()) {
            if (conn == null) return;
            conn.setAutoCommit(false);

            try (PreparedStatement pstmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, member.getName());
                pstmt.setString(2, member.getLastName());
                pstmt.setString(3, member.getPhone());
                pstmt.setString(4, member.getEmail());
                pstmt.executeUpdate();


                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    int generatedId = rs.getInt(1);


                    String idStr = String.valueOf(generatedId);
                    String defaultPassword = idStr.length() >= 4 ?
                            idStr.substring(idStr.length() - 4) :
                            String.format("%04d", generatedId);


                    try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateSql)) {
                        pstmtUpdate.setString(1, defaultPassword);
                        pstmtUpdate.setInt(2, generatedId);
                        pstmtUpdate.executeUpdate();
                    }

                    conn.commit();
                    JOptionPane.showMessageDialog(null, "Üye Kaydı Başarılı!\nKullanıcı ID (Giriş No): " + generatedId + "\nVarsayılan Şifre: " + defaultPassword);
                }
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Hata: Kayıt oluşturulamadı.");
        }
    }

    public void createRequest(int memberId, int itemId) {
        String sql = "INSERT INTO requests (member_id, item_id, request_type, status) VALUES (?, ?, 'BORROW', 'PENDING')";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, memberId);
            pstmt.setInt(2, itemId);
            pstmt.executeUpdate();
            System.out.println("Talep oluşturuldu, onay bekleniyor.");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public List<Request> getMemberRequests(int memberId) {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM requests WHERE member_id = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, memberId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new Request(
                        rs.getInt("request_id"),
                        rs.getInt("member_id"),
                        rs.getInt("item_id"),
                        rs.getString("request_type"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<LibraryPerson> getAllPeople() {
        List<LibraryPerson> people = new ArrayList<>();
        String sql = "SELECT * FROM library_people";
        try (Connection conn = ConnectDatabase.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String lastName = rs.getString("last_name");
                String role = rs.getString("role");
                String phone = rs.getString("phone");
                String email = rs.getString("email");

                if ("MEMBER".equals(role)) {
                    Members m = new Members(id, name, lastName, phone);
                    m.setEmail(email);
                    people.add(m);
                } else {
                    Officers o = new Officers(id, name, lastName, phone);
                    o.setEmail(email);
                    people.add(o);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return people;
    }

    public LibraryPerson getPersonById(int id) {
        String sql = "SELECT * FROM library_people WHERE id = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String role = rs.getString("role");
                String name = rs.getString("name");
                String lastName = rs.getString("last_name");
                String phone = rs.getString("phone");
                String email = rs.getString("email");

                if ("MEMBER".equals(role)) {
                    Members m = new Members(id, name, lastName, phone);
                    m.setEmail(email);
                    return m;
                } else {
                    Officers o = new Officers(id, name, lastName, phone);
                    o.setEmail(email);
                    return o;
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public void updatePersonInfo(int id, String name, String lastName, String email, String phone) {
        String sql = "UPDATE library_people SET name = ?, last_name = ?, email = ?, phone = ? WHERE id = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, lastName);
            pstmt.setString(3, email);
            pstmt.setString(4, phone);
            pstmt.setInt(5, id);
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public List<String[]> getUserBooksByStatus(int userId, String statusIgnored) {
        List<String[]> list = new ArrayList<>();

        String sql = "SELECT i.id, i.name, i.item_type FROM requests r " +
                "JOIN library_items i ON r.item_id = i.id " +
                "WHERE r.member_id = ? AND r.status = 'APPROVED'";

        try (Connection conn = database.ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {


            pstmt.setInt(1, userId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new String[]{
                            String.valueOf(rs.getInt("id")),
                            rs.getString("name"),
                            rs.getString("item_type")
                    });
                }
            }
        } catch (SQLException e) {
            System.err.println("getUserBooksByStatus hatası: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }

    public boolean updatePassword(int userId, String oldPass, String newPass) {
        String checkSql = "SELECT password FROM library_people WHERE id = ? AND password = ?";
        String updateSql = "UPDATE library_people SET password = ? WHERE id = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement checkPstmt = conn.prepareStatement(checkSql)) {
            checkPstmt.setInt(1, userId);
            checkPstmt.setString(2, oldPass);
            ResultSet rs = checkPstmt.executeQuery();
            if (rs.next()) {
                try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                    updatePstmt.setString(1, newPass);
                    updatePstmt.setInt(2, userId);
                    updatePstmt.executeUpdate();
                    return true;
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public List<String[]> getUniqueUserBookHistory(int memberId) {
        List<String[]> books = new ArrayList<>();
        String sql = "SELECT DISTINCT li.name, li.item_type FROM requests r " +
                "JOIN library_items li ON r.item_id = li.id " +
                "WHERE r.member_id = ? AND r.status = 'RETURNED' " +
                "ORDER BY li.item_type ASC, li.name ASC";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, memberId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                books.add(new String[]{rs.getString("name"), rs.getString("item_type")});
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return books;
    }

    public List<String[]> getUserRequestsByStatus(int userId, String status) {
        List<String[]> data = new ArrayList<>();
        String sql = "SELECT i.name, i.item_type, r.status FROM requests r " +
                "JOIN library_items i ON r.item_id = i.id " +
                "WHERE r.member_id = ? AND UPPER(r.status) = UPPER(?)";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, status);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String dbType = rs.getString("item_type");
                String dbStatus = rs.getString("status");
                String readableType = dbType.equalsIgnoreCase("BOOK") ? "Kitap" : (dbType.equalsIgnoreCase("DVD") ? "DVD" : "Dergi");
                String displayStatus = dbStatus.equalsIgnoreCase("PENDING") ? "⏳ Onay Bekliyor" :
                        (dbStatus.equalsIgnoreCase("RETURN_PENDING") ? "🔄 İade Onayı Bekliyor" : "🔄 İşlemde");
                data.add(new String[]{rs.getString("name"), readableType, displayStatus});
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return data;
    }

    public void cancelUserRequest(int userId, String itemName) {
        String findRequestSql =
                "SELECT r.request_id, r.item_id, r.status FROM requests r " +
                        "JOIN library_items i ON r.item_id = i.id " +
                        "WHERE r.member_id = ? AND i.name = ? AND r.status IN ('PENDING', 'RETURN_PENDING')";

        try (Connection conn = database.ConnectDatabase.getConnection()) {
            if (conn == null) return;
            conn.setAutoCommit(false);

            int requestId = -1;
            int itemId = -1;
            String currentStatus = "";

            try (PreparedStatement pstmt = conn.prepareStatement(findRequestSql)) {
                pstmt.setInt(1, userId);
                pstmt.setString(2, itemName);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    requestId = rs.getInt("request_id");
                    itemId = rs.getInt("item_id");
                    currentStatus = rs.getString("status");
                }
            }

            if (requestId != -1) {

                if ("RETURN_PENDING".equalsIgnoreCase(currentStatus)) {

                    String updateSql = "UPDATE requests SET status = 'APPROVED' WHERE request_id = ?";
                    try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateSql)) {
                        pstmtUpdate.setInt(1, requestId);
                        pstmtUpdate.executeUpdate();
                    }
                    System.out.println("İade işlemi iptal edildi, kitap 'Eldekiler' listesine geri döndü.");
                }

                else {

                    String restoreSql = "UPDATE library_items SET is_available = 1 WHERE id = ?";
                    try (PreparedStatement pstmtRestore = conn.prepareStatement(restoreSql)) {
                        pstmtRestore.setInt(1, itemId);
                        pstmtRestore.executeUpdate();
                    }

                    String deleteSql = "DELETE FROM requests WHERE request_id = ?";
                    try (PreparedStatement pstmtDelete = conn.prepareStatement(deleteSql)) {
                        pstmtDelete.setInt(1, requestId);
                        pstmtDelete.executeUpdate();
                    }
                    System.out.println("Ödünç talebi silindi, kitap rafa geri döndü.");
                }
            }

            conn.commit();
        } catch (SQLException e) {
            System.err.println("İptal işlemi sırasında hata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void deletePerson(int personId) {
        String deleteRequestsSql = "DELETE FROM requests WHERE member_id = ?";
        String deletePersonSql = "DELETE FROM library_people WHERE id = ?";
        try (Connection conn = ConnectDatabase.getConnection()) {
            if (conn == null) return;
            conn.setAutoCommit(false);
            try (PreparedStatement psReq = conn.prepareStatement(deleteRequestsSql);
                 PreparedStatement psPers = conn.prepareStatement(deletePersonSql)) {
                psReq.setInt(1, personId);
                psReq.executeUpdate();
                psPers.setInt(1, personId);
                psPers.executeUpdate();
                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
    public int getTotalMemberCount() {
        int count = 0;

        String sql = "SELECT COUNT(*) FROM library_people WHERE role = 'MEMBER'";

        try (Connection conn = ConnectDatabase.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public void deleteUser(int userId) {

        String deleteRequests = "DELETE FROM requests WHERE member_id = ?";
        String deleteUser = "DELETE FROM library_people WHERE id = ?";

        try (Connection conn = database.ConnectDatabase.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement psReq = conn.prepareStatement(deleteRequests);
                 PreparedStatement psUser = conn.prepareStatement(deleteUser)) {

                psReq.setInt(1, userId);
                psReq.executeUpdate();

                psUser.setInt(1, userId);
                psUser.executeUpdate();

                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.err.println("Kullanıcı silme hatası: " + e.getMessage());
        }
    }
}