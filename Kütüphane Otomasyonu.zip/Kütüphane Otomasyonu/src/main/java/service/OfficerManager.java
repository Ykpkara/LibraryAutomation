package service;

import database.ConnectDatabase;
import model.Officers;
import model.Request;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OfficerManager {


    public void addOfficer(Officers officer) {
        String insertSql = "INSERT INTO library_people (name, last_name, role, phone, email, password) VALUES (?, ?, 'OFFICER', ?, ?, 'TEMP')";
        String updateSql = "UPDATE library_people SET password = ? WHERE id = ?";

        try (Connection conn = ConnectDatabase.getConnection()) {
            if (conn == null) return;
            conn.setAutoCommit(false);

            try (PreparedStatement pstmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, officer.getName());
                pstmt.setString(2, officer.getLastName());
                pstmt.setString(3, officer.getPhone());
                pstmt.setString(4, officer.getEmail());
                pstmt.executeUpdate();


                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    int generatedId = rs.getInt(1);


                    String idStr = String.valueOf(generatedId);
                    String defaultPassword = idStr.length() >= 4 ?
                            idStr.substring(idStr.length() - 4) :
                            String.format("%04d", generatedId);


                    try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateSql)) {
                        pstmtUpdate.setString(1, defaultPassword);
                        pstmtUpdate.setInt(2, generatedId);
                        pstmtUpdate.executeUpdate();
                    }

                    conn.commit();
                    JOptionPane.showMessageDialog(null, "Görevli Kaydı Başarılı!\nKullanıcı ID (Giriş No): " + generatedId + "\nVarsayılan Şifre: " + defaultPassword);
                }
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Görevli eklenirken hata oluştu!");
        }
    }


    public void handleRequest(int requestId, String status) {

        String updateReqSql = "UPDATE requests SET status = ? WHERE request_id = ?";
        String getRequestDetailsSql = "SELECT item_id, request_type FROM requests WHERE request_id = ?";
        String updateItemSql = "UPDATE library_items SET is_available = ? WHERE id = ?";

        try (Connection conn = ConnectDatabase.getConnection()) {
            if (conn == null) return;


            conn.setAutoCommit(false);

            try (PreparedStatement psUpdate = conn.prepareStatement(updateReqSql);
                 PreparedStatement psGetDetails = conn.prepareStatement(getRequestDetailsSql);
                 PreparedStatement psUpdateItem = conn.prepareStatement(updateItemSql)) {


                psUpdate.setString(1, status);
                psUpdate.setInt(2, requestId);
                psUpdate.executeUpdate();


                psGetDetails.setInt(1, requestId);
                int itemId = -1;
                String requestType = "";

                try (ResultSet rs = psGetDetails.executeQuery()) {
                    if (rs.next()) {
                        itemId = rs.getInt("item_id");
                        requestType = rs.getString("request_type");
                    }
                }


                if (itemId != -1) {
                    if ("APPROVED".equals(status)) {

                        psUpdateItem.setBoolean(1, false);
                        psUpdateItem.setInt(2, itemId);
                        psUpdateItem.executeUpdate();
                    }
                    else if ("RETURNED".equals(status)) {

                        psUpdateItem.setBoolean(1, true);
                        psUpdateItem.setInt(2, itemId);
                        psUpdateItem.executeUpdate();
                    }
                    else if ("REJECTED".equals(status)) {

                        boolean isNowAvailable = requestType.equals("BORROW");
                        psUpdateItem.setBoolean(1, isNowAvailable);
                        psUpdateItem.setInt(2, itemId);
                        psUpdateItem.executeUpdate();
                    }
                }


                conn.commit();
                System.out.println("✅ Talep #" + requestId + " başarıyla işlendi ve envanter güncellendi.");

            } catch (SQLException ex) {

                conn.rollback();
                System.err.println("❌ İşlem sırasında hata oluştu, geri alınıyor: " + ex.getMessage());
                throw ex;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateItemAvailability(Connection conn, int itemId, boolean isAvailable) throws SQLException {
        String sql = "UPDATE library_items SET is_available = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, isAvailable);
            pstmt.setInt(2, itemId);
            pstmt.executeUpdate();
        }
    }

    public List<Request> getAllPendingRequests() {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM requests WHERE UPPER(status) IN ('PENDING', 'RETURN_PENDING')";

        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(new Request(
                        rs.getInt("request_id"),
                        rs.getInt("member_id"),
                        rs.getInt("item_id"),
                        rs.getString("request_type"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean isItemUnderRequest(int itemId) {
        String sql = "SELECT COUNT(*) FROM requests WHERE item_id = ? AND status IN ('PENDING', 'RETURN_PENDING')";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, itemId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public void createReturnRequest(int memberId, int itemId) {

        String sql = "UPDATE requests SET status = 'RETURN_PENDING', request_type = 'RETURN' WHERE member_id = ? AND item_id = ? AND status = 'APPROVED'";

        try (Connection conn = database.ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, memberId);
            pstmt.setInt(2, itemId);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("✅ İade talebi oluşturuldu (Status: RETURN_PENDING, Type: RETURN)");
            } else {
                System.out.println("⚠️ İade talebi oluşturulamadı! Kayıt bulunamadı veya zaten iade edilmiş.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void createRequest(int memberId, int itemId, String type) {
        String sql = "INSERT INTO requests (member_id, item_id, request_type, status) VALUES (?, ?, ?, 'PENDING')";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, memberId);
            pstmt.setInt(2, itemId);
            pstmt.setString(3, type);
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public int getActiveRequestCount(int memberId) {
        String sql = "SELECT COUNT(*) FROM requests WHERE member_id = ? AND (status = 'PENDING' OR status = 'APPROVED')";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, memberId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<Object[]> getItemTypeStatistics() {
        List<Object[]> stats = new ArrayList<>();


        String sql = "SELECT i.item_type, COUNT(i.id) as total, " +
                "SUM(CASE WHEN i.is_available = 0 THEN 1 ELSE 0 END) as on_loan, " +
                "(SELECT COUNT(*) FROM requests r WHERE r.item_id IN " +
                "(SELECT id FROM library_items WHERE item_type = i.item_type) AND r.status = 'PENDING') as pending " +
                "FROM library_items i GROUP BY i.item_type";

        try (Connection conn = database.ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                stats.add(new Object[]{
                        rs.getString("item_type"),
                        rs.getInt("total"),
                        rs.getInt("on_loan"),
                        rs.getInt("pending")
                });
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return stats;
    }

    public List<Object[]> getDetailedProductStats(String itemType) {
        List<Object[]> stats = new ArrayList<>();


        String sql = "SELECT i.id, i.name, i.item_type, i.is_available, " +
                "r.status, r.member_id, p.name as person_name " +
                "FROM library_items i " +
                "LEFT JOIN requests r ON i.id = r.item_id " +
                "AND r.status IN ('APPROVED', 'PENDING', 'RETURN_PENDING') " +
                "LEFT JOIN library_people p ON r.member_id = p.id " +
                "WHERE i.item_type = ? " +
                "ORDER BY i.id ASC";

        try (Connection conn = database.ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, itemType);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String rawStatus = rs.getString("status");
                    int available = rs.getInt("is_available");
                    String displayStatus = "Kütüphanede";


                    Integer memberId = (rs.getObject("member_id") != null) ? rs.getInt("member_id") : null;
                    String personName = rs.getString("person_name");


                    if ("PENDING".equals(rawStatus)) {
                        displayStatus = "Alım Onayı Bekliyor";
                    } else if ("RETURN_PENDING".equals(rawStatus)) {
                        displayStatus = "İade Onayı Bekliyor";
                    } else if (available == 0 || "APPROVED".equals(rawStatus)) {
                        displayStatus = "Ödünçte";
                    }


                    if (displayStatus.equals("Kütüphanede")) {
                        memberId = null;
                        personName = null;
                    }

                    stats.add(new Object[]{
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("item_type"),
                            displayStatus,
                            (memberId == null) ? "-" : memberId,
                            (personName == null) ? "-" : personName
                    });
                }
            }
        } catch (SQLException e) {
            System.err.println("Detaylı istatistik hatası: " + e.getMessage());
            e.printStackTrace();
        }
        return stats;
    }

    public void deleteItem(int itemId) {

        String deleteRequestsSql = "DELETE FROM requests WHERE item_id = ?";
        String deleteItemSql = "DELETE FROM library_items WHERE id = ?";

        try (Connection conn = database.ConnectDatabase.getConnection()) {

            conn.setAutoCommit(false);

            try (PreparedStatement pstmtReq = conn.prepareStatement(deleteRequestsSql);
                 PreparedStatement pstmtItem = conn.prepareStatement(deleteItemSql)) {


                pstmtReq.setInt(1, itemId);
                pstmtReq.executeUpdate();


                pstmtItem.setInt(1, itemId);
                pstmtItem.executeUpdate();


                conn.commit();
                System.out.println("ID: " + itemId + " olan ürün ve bağlı talepleri silindi.");

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.err.println("Ürün silme hatası: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
