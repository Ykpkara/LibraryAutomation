package service;

import database.ConnectDatabase;
import model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemManager {

    // --- KİTAP EKLEME ---
    // Değişiklik: Parametreler nesne yerine (String, int) olarak güncellendi.
    // Değişiklik: SQL sorgusundan 'id' çıkarıldı (AUTO_INCREMENT).
    public void addBook(String name, String author, int pageNumber) {
        String sql = "INSERT INTO library_items (name, item_type, author, page_number, is_available) VALUES (?, 'BOOK', ?, ?, 1)";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, author);
            pstmt.setInt(3, pageNumber);
            // 4. parametreye gerek yok, is_available 1 (true) olarak hardcode edildi.

            pstmt.executeUpdate();
            System.out.println("Kitap eklendi: " + name);
        } catch (SQLException e) {
            System.err.println("Kitap ekleme hatası: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // --- DVD EKLEME ---
    public void addDvd(String name, String brand) {
        String sql = "INSERT INTO library_items (name, item_type, brand, is_available) VALUES (?, 'DVD', ?, 1)";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, brand);

            pstmt.executeUpdate();
            System.out.println("DVD eklendi: " + name);
        } catch (SQLException e) {
            System.err.println("DVD ekleme hatası: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // --- DERGİ EKLEME ---
    public void addMagazine(String name, String publisher) {

        String sql = "INSERT INTO library_items (name, item_type, brand, is_available) VALUES (?, 'MAGAZINE', ?, 1)";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, publisher);

            pstmt.executeUpdate();
            System.out.println("Dergi eklendi: " + name);
        } catch (SQLException e) {
            System.err.println("Dergi ekleme hatası: " + e.getMessage());
            e.printStackTrace();
        }
    }


    public void deleteItem(int id) {

        String sql = "DELETE FROM library_items WHERE id = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            System.out.println("Öğe silindi ID: " + id);
        } catch (SQLException e) {
            System.err.println("Silme hatası: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<LibraryItem> getAllItems() {
        List<LibraryItem> items = new ArrayList<>();
        String sql = "SELECT * FROM library_items ORDER BY id DESC"; // En son eklenenler üstte görünsün
        try (Connection conn = ConnectDatabase.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String type = rs.getString("item_type");
                int id = rs.getInt("id");
                String name = rs.getString("name");
                boolean available = rs.getBoolean("is_available");


                String author = rs.getString("author");
                String brand = rs.getString("brand");
                int pages = rs.getInt("page_number");

                if ("BOOK".equals(type)) {
                    items.add(new Book(id, name, pages, author, available));
                } else if ("DVD".equals(type)) {
                    items.add(new Dvd(id, name, brand, available));
                } else if ("MAGAZINE".equals(type)) {

                    items.add(new Magazine(id, name, pages, brand, available));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }


    public void updateAvailability(int id, boolean status) {
        String sql = "UPDATE library_items SET is_available = ? WHERE id = ?";
        try (Connection conn = ConnectDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, status);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}